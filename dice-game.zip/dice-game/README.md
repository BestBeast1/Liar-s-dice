# Liar's Dice — Setup Guide

## What you need
- A free Supabase account (supabase.com)
- A free Netlify or GitHub Pages account (to host the game online)
- 10 minutes

---

## STEP 1 — Create a Supabase project

1. Go to https://supabase.com and sign up (free)
2. Click **"New project"**
3. Give it a name like `dice-game`, choose a region close to you, set a database password
4. Wait ~2 minutes for it to be ready

---

## STEP 2 — Create the database table

1. In your Supabase project, click **"SQL Editor"** in the left sidebar
2. Click **"New query"**
3. Paste the contents of `supabase_schema.sql` (included in this folder)
4. Click **"Run"** (green button)
5. You should see "Success. No rows returned"

---

## STEP 3 — Get your API keys

1. In Supabase, click **"Settings"** (gear icon) → **"API"**
2. Copy the **Project URL** (looks like `https://xyzabc.supabase.co`)
3. Copy the **anon / public** key (long string starting with `eyJ...`)

---

## STEP 4 — Paste keys into config.js

Open `config.js` and replace:
```
const SUPABASE_URL      = 'YOUR_SUPABASE_URL';
const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';
```

With your actual values:
```
const SUPABASE_URL      = 'https://xyzabc.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...';
```

---

## STEP 5 — Enable Realtime on the table

1. In Supabase, go to **"Database"** → **"Replication"**
2. Under "Realtime", click **"0 tables"** next to supabase_realtime
3. Toggle on the **rooms** table
4. Click **"Save"**

---

## STEP 6 — Deploy the game online (Netlify — free)

### Option A: Drag & drop (easiest)
1. Go to https://netlify.com and sign up
2. Go to **"Sites"** → drag the entire `dice-game` folder onto the page
3. Netlify gives you a free URL like `https://happy-dice-abc123.netlify.app`
4. Share that link with your friends!

### Option B: GitHub Pages
1. Create a GitHub account and a new repository
2. Upload all 3 files (index.html, config.js, supabase_schema.sql)
3. Go to repository **Settings** → **Pages** → Source: "main branch"
4. Your game is live at `https://yourusername.github.io/repositoryname`

---

## STEP 7 — Test it

1. Open the link in two different browser tabs (or share with a friend)
2. Both enter names and join the same room from the lobby
3. Host clicks "Start game"
4. Each player shakes their cup — dice are hidden from others
5. Players bid using the controls or chat the numbers
6. Anyone calls "Open" to reveal all dice!

---

## Files in this folder

| File | Purpose |
|------|---------|
| `index.html` | The entire game (HTML + CSS + JS) |
| `config.js` | Your Supabase credentials go here |
| `supabase_schema.sql` | Run this once in Supabase SQL editor |
| `README.md` | This guide |

---

## Troubleshooting

**"Setup required" banner shows** → You haven't filled in config.js yet

**Rooms don't update in real-time** → Make sure you enabled Realtime on the rooms table (Step 5)

**Players can't see each other** → Check that the SQL schema was run and the RLS policy was created

**Game works but slow** → Choose a Supabase region closer to your location
